import pandas as pd
from sklearn.tree import DecisionTreeRegressor
import joblib
import datetime

rawdata=pd.read_csv("DailyTemperatures.csv")
X=rawdata.drop(columns=['AvgTemperature','Region','Country','City'])
y=rawdata['AvgTemperature']

model=DecisionTreeRegressor()
model.fit(X,y)
c=int(input("Enter the City Code"))
m=int(input("Enter Month Number (Jan to Dec 1 to 12) "))
d=int(input("Enter the Date "))
today=datetime.date.today()
y=today.year
p=model.predict([[c,m,d,y]])
t=p[0]
t=(t-32)*(5/9)
print("The Temperature on %d/%d is most likely going to be %.2f Celsius "%(d,m,t))

joblib.dump(model,'TemperatureMLModel.joblib')